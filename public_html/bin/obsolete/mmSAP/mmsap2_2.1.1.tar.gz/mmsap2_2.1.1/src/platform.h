#ifndef _PLATFORM_H
#define	_PLATFORM_H


/*Uncomment this and recompile if you want to perform
 *some testing !*/

/*#define DEBUG_PRINTOUTS*/




#endif	/* _PLATFORM_H */

