#include "columnmodel.h"

ColumnModel::ColumnModel() {
    add(clmCurrent);
    add(clmFilespec);
    add(clmFilename);
}
