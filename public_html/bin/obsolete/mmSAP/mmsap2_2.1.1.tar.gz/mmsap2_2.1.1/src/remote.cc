#include "remote.h"


/*External functions*/
void loadAndPlayFile(Glib::ustring fspec,bool shout=true);
void quit(bool fromRemote);

Remote::Remote() {
    valid=false;
    bus=NULL;
    error=NULL;
    
}

void Remote::init() {
    
    valid=false;
    
    dbus_g_thread_init();
    
    /*Try to obtain bus*/
    bus=dbus_g_bus_get(DBUS_BUS_SESSION,&error);
    if (bus==NULL || error!=NULL) {
        #ifdef DEBUG_PRINTOUTS
        printf("Remote:: d-bus not connected: %s\n",error->message);
        #endif
        if (error!=NULL) g_error_free(error);
        return;
    }
    
    /*Listen to the bus*/
    dbus_bus_add_match (dbus_g_connection_get_connection(bus), "type='signal',interface='org.cs.baktra.mmsap2.Signal'",NULL);
    dbus_connection_add_filter (dbus_g_connection_get_connection(bus), Remote::on_filter, this, NULL);
    
    valid=true;
    #ifdef DEBUG_PRINTOUTS
    printf("Remote:: d-bus connection established\n");
    #endif
    
}

bool Remote::sendTerminateMessage() {
    if (valid==false) return false;
    DBusMessage* sentMessage=NULL;
    
    sentMessage=dbus_message_new_signal("/org/cs/baktra/mmsap2/fspec","org.cs.baktra.mmsap2.Signal","terminate");
    if (sentMessage==NULL) return false;
    
    /*Send only pid*/
    dbus_uint32_t pid = getpid();
    dbus_message_append_args (sentMessage,DBUS_TYPE_UINT32,&pid,DBUS_TYPE_INVALID);
    dbus_connection_send(dbus_g_connection_get_connection(bus), sentMessage,NULL);
    
    dbus_message_unref (sentMessage);
    
    return true;
}


bool Remote::sendFilespecMessage(Glib::ustring fspec) {
    if (valid==false) return false;
    
    /*Construct signal message*/
    DBusMessage* sentMessage=NULL;
    
    
    sentMessage=dbus_message_new_signal("/org/cs/baktra/mmsap2/fspec","org.cs.baktra.mmsap2.Signal","fspec");
    if (sentMessage==NULL) return false;
    
    /*Send filespec and our pid*/
    const char* fsp = fspec.c_str();
    dbus_uint32_t pid = getpid();
    dbus_message_append_args (sentMessage,DBUS_TYPE_STRING,&fsp,DBUS_TYPE_UINT32,&pid,DBUS_TYPE_INVALID);
    dbus_connection_send(dbus_g_connection_get_connection(bus), sentMessage,NULL);
    
    dbus_message_unref (sentMessage);
    
    return true;
}

DBusHandlerResult Remote::on_filter (DBusConnection *connection, DBusMessage *message, void *user_data) {
    
    /*fspec singal ?*/
    if (dbus_message_is_signal (message, "org.cs.baktra.mmsap2.Signal", "fspec")) {
        
        DBusError error;
        char *fsp = NULL;
        dbus_uint32_t pid=0; 
        
        dbus_error_init (&error);
        if (dbus_message_get_args(message, &error, DBUS_TYPE_STRING, &fsp,DBUS_TYPE_UINT32,&pid,DBUS_TYPE_INVALID)) {
            
            #ifdef DEBUG_PRINTOUTS
            printf("Process: %u received FSPEC %s from %u\n",getpid(),fsp,pid);
            #endif
            
            /*If this message is not from us, try to load the tune*/
            if (pid!=getpid()) {
                ((Remote*)user_data)->sendTerminateMessage();
                gdk_threads_enter();
                Glib::ustring gfsp(fsp);
                if (gfsp!="") {
                    loadAndPlayFile(Glib::ustring(fsp),false);
                }
                gdk_threads_leave();
            }
            
        } 
        /*Failed to get args*/
        else {
            dbus_error_free (&error);
        }
        return DBUS_HANDLER_RESULT_HANDLED;
    }/*fspec signal*/
    
    /*terminate signal*/
    else if (dbus_message_is_signal(message, "org.cs.baktra.mmsap2.Signal", "terminate")) {
        
        DBusError error;
        dbus_uint32_t pid=0; 
        
        dbus_error_init (&error);
        if (dbus_message_get_args(message, &error,DBUS_TYPE_UINT32,&pid,DBUS_TYPE_INVALID)) {
            
            #ifdef DEBUG_PRINTOUTS
            printf("Process: %u received QUIT from %u\n",getpid(),pid);
            #endif
            
            /*If this message is not from us, terminate*/
            if (pid!=getpid()) {
                gdk_threads_enter();
                quit(true);
                gdk_threads_leave();
            }
            
        } 
        /*Failed to get args*/
        else {
            dbus_error_free (&error);
        }
        return DBUS_HANDLER_RESULT_HANDLED;
    }
    
    return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
}

void Remote::destroy() {
    if (valid==false) return;
}
