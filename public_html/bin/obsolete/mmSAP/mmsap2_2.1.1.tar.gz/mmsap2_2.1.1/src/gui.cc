#include "preferences.h"

#include "gui.h"

/*Event handlers*/
extern void on_loadSAP();
extern void on_playOrPause();
extern void on_stop();
extern void on_previous();
extern void on_next();
extern void on_seek();
extern void on_moveSlider(Gtk::ScrollType sct);
extern void on_handleRepeatMode();
extern void on_playerDrop(const Glib::RefPtr<Gdk::DragContext>& context, int x, int y, const Gtk::SelectionData& selection_data, guint info, guint time);
extern void on_playlistDrop(const Glib::RefPtr<Gdk::DragContext>& context, int x, int y, const Gtk::SelectionData& selection_data, guint info, guint time);
extern bool on_aboutClose(GdkEventAny* evt);
extern void on_aboutInvoke();
extern void on_quitInvoke();
extern void on_preferencesInvoke();
extern bool on_preferencesClose(GdkEventAny* evt);
extern bool on_wndMainClose(GdkEventAny* evt);
extern void on_advancedControlsToggled();
extern void on_channelMuteChange();
extern void on_addFileToPlaylist();
extern void on_addDirectoryToPlaylist();
extern void on_playlistItemActivated(const Gtk::TreeModel::Path& path, Gtk::TreeViewColumn* column);
extern void on_savePlaylist();
extern void on_loadPlaylist();
extern void on_nextTune();
extern void on_previousTune();
extern void on_removeAllFromPlaylist();
extern void on_removeSelectedFromPlaylist();
extern void on_trimPlaylistSelection();
extern void on_purgePlaylist();
extern bool on_fcdBrowseAndPlayClose(GdkEventAny* evt);
extern void on_fcdBrowseAndPlayFileActivated();
extern void on_browseAndPlay();
extern void on_browseAndPlayClose();
extern void on_addPlayerFile();


#include "gladegui/mmsap2.ui.h"


void GUI::create() {
    
    /*Pre initialization*/
    tickUpdateBlocked=false;
    
    
    /*Create XML object*/
    GtkBuilder* xml = gtk_builder_new();
    gtk_builder_add_from_string(xml,(const gchar*)mmsap2_ui,MMSAP2_UI_LENGTH,NULL);
    

    
    /*Main window and player*/
    wndMain = Glib::wrap(GTK_WINDOW(gtk_builder_get_object(xml,"wndMain")));
    fcdLoad=Glib::wrap(GTK_FILE_CHOOSER_DIALOG(gtk_builder_get_object(xml,"fcdLoad")));
    btnPlayOrPause = Glib::wrap(GTK_BUTTON(gtk_builder_get_object(xml,"btnPlayOrPause")));
    mniLoadSAP = Glib::wrap(GTK_IMAGE_MENU_ITEM(gtk_builder_get_object(xml,"mniLoadSAP")));
    btnStop=Glib::wrap(GTK_BUTTON(gtk_builder_get_object(xml,"btnStop")));
    btnPrevious=Glib::wrap(GTK_BUTTON(gtk_builder_get_object(xml,"btnPrevious")));
    btnNext=Glib::wrap(GTK_BUTTON(gtk_builder_get_object(xml,"btnNext")));
    hscSeeking=Glib::wrap(GTK_HSCALE(gtk_builder_get_object(xml,"hscSeeking")));
    lblSongCounter=Glib::wrap(GTK_LABEL(gtk_builder_get_object(xml,"lblSongCounter")));
    lblElapsedTime=Glib::wrap(GTK_LABEL(gtk_builder_get_object(xml,"lblElapsedTime")));
    lblFilename=Glib::wrap(GTK_LABEL(gtk_builder_get_object(xml,"lblFilename")));
    tgbAdvancedControls=Glib::wrap(GTK_TOGGLE_BUTTON(gtk_builder_get_object(xml,"tgbAdvancedControls")));
    btnNextTune=Glib::wrap(GTK_BUTTON(gtk_builder_get_object(xml,"btnNextTune")));
    btnPreviousTune=Glib::wrap(GTK_BUTTON(gtk_builder_get_object(xml,"btnPreviousTune")));
    lblTuneInfo=Glib::wrap(GTK_LABEL(gtk_builder_get_object(xml,"lblTuneInfo")));
    
    /*Browse and play*/
    mniBrowseAndPlay = Glib::wrap(GTK_IMAGE_MENU_ITEM(gtk_builder_get_object(xml,"mniBrowseAndPlay")));
    fcdBrowseAndPlay = Glib::wrap(GTK_FILE_CHOOSER_DIALOG(gtk_builder_get_object(xml,"fcdBrowseAndPlay")));
    btnBrowseAndPlayClose = Glib::wrap(GTK_BUTTON(gtk_builder_get_object(xml,"btnBrowseAndPlayClose")));
    
    /*Player's drag and drop vbox*/
    vbxPlayerBox=Glib::wrap(GTK_VBOX(gtk_builder_get_object(xml,"vbxPlayerBox")));
    
    std::list<Gtk::TargetEntry> playerTgtList;
    vbxPlayerBox->drag_dest_set(playerTgtList,Gtk::DEST_DEFAULT_ALL,Gdk::ACTION_DEFAULT|Gdk::ACTION_MOVE|Gdk::ACTION_COPY);	
    vbxPlayerBox->drag_dest_add_uri_targets();
    vbxPlayerBox->drag_dest_add_text_targets();
    
    /*Advanced controls*/
    ntbAdvancedControls=Glib::wrap(GTK_NOTEBOOK(gtk_builder_get_object(xml,"ntbAdvancedControls")));
    txvTuneInfo=Glib::wrap(GTK_TEXT_VIEW(gtk_builder_get_object(xml,"txvTuneInfo")));
    
    /*Channel mutes*/
    chbChannelMutes[0]=Glib::wrap(GTK_CHECK_BUTTON(gtk_builder_get_object(xml,"chbMuteChan0")));
    chbChannelMutes[1]=Glib::wrap(GTK_CHECK_BUTTON(gtk_builder_get_object(xml,"chbMuteChan1")));
    chbChannelMutes[2]=Glib::wrap(GTK_CHECK_BUTTON(gtk_builder_get_object(xml,"chbMuteChan2")));
    chbChannelMutes[3]=Glib::wrap(GTK_CHECK_BUTTON(gtk_builder_get_object(xml,"chbMuteChan3")));
    chbChannelMutes[4]=Glib::wrap(GTK_CHECK_BUTTON(gtk_builder_get_object(xml,"chbMuteChan4")));
    chbChannelMutes[5]=Glib::wrap(GTK_CHECK_BUTTON(gtk_builder_get_object(xml,"chbMuteChan5")));
    chbChannelMutes[6]=Glib::wrap(GTK_CHECK_BUTTON(gtk_builder_get_object(xml,"chbMuteChan6")));
    chbChannelMutes[7]=Glib::wrap(GTK_CHECK_BUTTON(gtk_builder_get_object(xml,"chbMuteChan7")));
    
    /*Repeat*/
    mniRepNothing=Glib::wrap(GTK_RADIO_MENU_ITEM(gtk_builder_get_object(xml,"mniRepNothing")));
    mniRepSubsong=Glib::wrap(GTK_RADIO_MENU_ITEM(gtk_builder_get_object(xml,"mniRepSubsong")));
    mniRepTune=Glib::wrap(GTK_RADIO_MENU_ITEM(gtk_builder_get_object(xml,"mniRepTune")));
    mniRepPlaylist=Glib::wrap(GTK_RADIO_MENU_ITEM(gtk_builder_get_object(xml,"mniRepPlaylist")));
    
    /*About*/
    dlgAbout=Glib::wrap(GTK_DIALOG(gtk_builder_get_object(xml,"dlgAbout")));
    mniAbout=Glib::wrap(GTK_IMAGE_MENU_ITEM(gtk_builder_get_object(xml,"mniAbout")));
    lblVersion=Glib::wrap(GTK_LABEL(gtk_builder_get_object(xml,"lblVersion")));
    
    /*Quit*/
    mniQuit=Glib::wrap(GTK_IMAGE_MENU_ITEM(gtk_builder_get_object(xml,"mniQuit")));
    
    /*Preferences*/
    mniPreferences=Glib::wrap(GTK_IMAGE_MENU_ITEM(gtk_builder_get_object(xml,"mniPreferences")));
    dlgPreferences=Glib::wrap(GTK_DIALOG(gtk_builder_get_object(xml,"dlgPreferences")));
    chbUseDefaultDirectory=Glib::wrap(GTK_CHECK_BUTTON(gtk_builder_get_object(xml,"chbUseDefaultDirectory")));
    entDefaultDirectory=Glib::wrap(GTK_ENTRY(gtk_builder_get_object(xml,"entDefaultDirectory")));
    hscSilenceLimit=Glib::wrap(GTK_HSCALE(gtk_builder_get_object(xml,"hscSilenceLimit")));
    chbAlwaysFirstSubsong=Glib::wrap(GTK_CHECK_BUTTON(gtk_builder_get_object(xml,"chbAlwaysFirstSubsong")));
    spbVisualizationPeriod=Glib::wrap(GTK_SPIN_BUTTON(gtk_builder_get_object(xml,"spbVisualizationPeriod")));
    chbAdvancedControlsShownByDefault=Glib::wrap(GTK_CHECK_BUTTON(gtk_builder_get_object(xml,"chbAdvancedControlsShownByDefault")));
    hscVisualizationSynchro=Glib::wrap(GTK_HSCALE(gtk_builder_get_object(xml,"hscVisualizationSynchro")));
    entAsmaDirectory=Glib::wrap(GTK_ENTRY(gtk_builder_get_object(xml,"entAsmaDirectory")));
    entStilFile=Glib::wrap(GTK_ENTRY(gtk_builder_get_object(xml,"entStilFile")));
    chbUseStil=Glib::wrap(GTK_CHECK_BUTTON(gtk_builder_get_object(xml,"chbUseStil")));
    entAlsaDevice=Glib::wrap(GTK_ENTRY(gtk_builder_get_object(xml,"entAlsaDevice")));
    chbAlwaysStereo=Glib::wrap(GTK_CHECK_BUTTON(gtk_builder_get_object(xml,"chbAlwaysStereo")));
    chbNormalizeSAPHeader=Glib::wrap(GTK_CHECK_BUTTON(gtk_builder_get_object(xml,"chbNormalizeSAPHeader")));
    spbVisualizationDecrement=Glib::wrap(GTK_SPIN_BUTTON(gtk_builder_get_object(xml,"spbVisualizationDecrement")));
    btnBrowseASMADir = Glib::wrap(GTK_BUTTON(gtk_builder_get_object(xml,"btnBrowseASMADir")));
    btnBrowseSTIL = Glib::wrap(GTK_BUTTON(gtk_builder_get_object(xml,"btnBrowseSTIL")));

    /*Visualization*/
    prbChans[0]=Glib::wrap(GTK_PROGRESS_BAR(gtk_builder_get_object(xml,"prbChan1")));
    prbChans[1]=Glib::wrap(GTK_PROGRESS_BAR(gtk_builder_get_object(xml,"prbChan2")));
    prbChans[2]=Glib::wrap(GTK_PROGRESS_BAR(gtk_builder_get_object(xml,"prbChan3")));
    prbChans[3]=Glib::wrap(GTK_PROGRESS_BAR(gtk_builder_get_object(xml,"prbChan4")));
    prbChans[4]=Glib::wrap(GTK_PROGRESS_BAR(gtk_builder_get_object(xml,"prbChan5")));
    prbChans[5]=Glib::wrap(GTK_PROGRESS_BAR(gtk_builder_get_object(xml,"prbChan6")));
    prbChans[6]=Glib::wrap(GTK_PROGRESS_BAR(gtk_builder_get_object(xml,"prbChan7")));
    prbChans[7]=Glib::wrap(GTK_PROGRESS_BAR(gtk_builder_get_object(xml,"prbChan8")));
    
    /*Playlist*/
    trvPlaylist=Glib::wrap(GTK_TREE_VIEW(gtk_builder_get_object(xml,"trvPlaylist")));
    mniAddFileToPlaylist=Glib::wrap(GTK_IMAGE_MENU_ITEM(gtk_builder_get_object(xml,"mniAddFileToPlaylist")));
    mniAddDirectoryToPlaylist=Glib::wrap(GTK_IMAGE_MENU_ITEM(gtk_builder_get_object(xml,"mniAddDirectoryToPlaylist")));
    fcdAddToPlaylist=Glib::wrap(GTK_FILE_CHOOSER_DIALOG(gtk_builder_get_object(xml,"fcdAddToPlaylist")));
    mniSavePlaylist=Glib::wrap(GTK_IMAGE_MENU_ITEM(gtk_builder_get_object(xml,"mniSavePlaylist")));
    mniLoadPlaylist=Glib::wrap(GTK_IMAGE_MENU_ITEM(gtk_builder_get_object(xml,"mniLoadPlaylist")));
    fcdPlaylist=Glib::wrap(GTK_FILE_CHOOSER_DIALOG(gtk_builder_get_object(xml,"fcdPlaylist")));
    mniPlaylistSelectNone=Glib::wrap(GTK_MENU_ITEM(gtk_builder_get_object(xml,"mniPlaylistSelectNone")));
    mniPlaylistSelectAll=Glib::wrap(GTK_MENU_ITEM(gtk_builder_get_object(xml,"mniPlaylistSelectAll")));
    mniPlaylistSelectInvert=Glib::wrap(GTK_MENU_ITEM(gtk_builder_get_object(xml,"mniPlaylistSelectInvert")));
    mniAddPlayerFile=Glib::wrap(GTK_IMAGE_MENU_ITEM(gtk_builder_get_object(xml,"mniAddPlayerFile")));
    mniPlaylistPurge=Glib::wrap(GTK_IMAGE_MENU_ITEM(gtk_builder_get_object(xml,"mniPlaylistPurge")));

    mniPlaylistTrimSelected=Glib::wrap(GTK_MENU_ITEM(gtk_builder_get_object(xml,"mniPlaylistTrimSelected")));
    mniPlaylistRemoveAll=Glib::wrap(GTK_IMAGE_MENU_ITEM(gtk_builder_get_object(xml,"mniPlaylistRemoveAll")));
    mniPlaylistRemoveSelected=Glib::wrap(GTK_IMAGE_MENU_ITEM(gtk_builder_get_object(xml,"mniPlaylistRemoveSelected")));
    
    vbxPlaylist=Glib::wrap(GTK_VBOX(gtk_builder_get_object(xml,"vbxPlaylist")));
    std::list<Gtk::TargetEntry> playlistTgtList;
    vbxPlaylist->drag_dest_set(playlistTgtList,Gtk::DEST_DEFAULT_ALL,Gdk::ACTION_DEFAULT|Gdk::ACTION_MOVE|Gdk::ACTION_COPY);	
    vbxPlaylist->drag_dest_add_uri_targets();
    vbxPlaylist->drag_dest_add_text_targets();

    
}

void GUI::connectSignals() {
    btnPlayOrPause->signal_clicked().connect(sigc::ptr_fun(&on_playOrPause),true);

    mniLoadSAP->signal_activate().connect(sigc::ptr_fun(&on_loadSAP),true);
    btnStop->signal_clicked().connect(sigc::ptr_fun(&on_stop),true);
    btnPrevious->signal_clicked().connect(sigc::ptr_fun(&on_previous),true);
    btnNext->signal_clicked().connect(sigc::ptr_fun(&on_next),true);
    vbxPlayerBox->signal_drag_data_received().connect(sigc::ptr_fun(&on_playerDrop),true);
    hscSeekingConnection=hscSeeking->signal_value_changed().connect(sigc::ptr_fun(&on_seek),true);
    hscSeeking->signal_button_press_event().connect(sigc::mem_fun(*this,&GUI::on_hscSeekingButtonPressed),false);
    hscSeeking->signal_button_release_event().connect(sigc::mem_fun(*this,&GUI::on_hscSeekingButtonReleased),false);
    tgbAdvancedControls->signal_toggled().connect(sigc::ptr_fun(&on_advancedControlsToggled),true);
    btnNextTune->signal_clicked().connect(sigc::ptr_fun(&on_nextTune),true);
    btnPreviousTune->signal_clicked().connect(sigc::ptr_fun(&on_previousTune),true);
    
    /*Browse and play*/
    mniBrowseAndPlay->signal_activate().connect(sigc::ptr_fun(&on_browseAndPlay),true);
    fcdBrowseAndPlay->signal_file_activated().connect(sigc::ptr_fun(&on_fcdBrowseAndPlayFileActivated),true);
    fcdBrowseAndPlay->signal_delete_event().connect(sigc::ptr_fun(&on_fcdBrowseAndPlayClose),true);
    btnBrowseAndPlayClose->signal_clicked().connect(sigc::ptr_fun(&on_browseAndPlayClose),true);

    
    
    /*Repeats*/
    mniRepNothing->signal_activate().connect(sigc::ptr_fun(&on_handleRepeatMode),true);
    mniRepSubsong->signal_activate().connect(sigc::ptr_fun(&on_handleRepeatMode),true);
    mniRepTune->signal_activate().connect(sigc::ptr_fun(&on_handleRepeatMode),true);
    mniRepPlaylist->signal_activate().connect(sigc::ptr_fun(&on_handleRepeatMode),true);

        
    /*About*/
    mniAbout->signal_activate().connect(sigc::ptr_fun(&on_aboutInvoke),true);
    dlgAbout->signal_delete_event().connect(sigc::ptr_fun(&on_aboutClose),true);
    
    /*Quit*/
    mniQuit->signal_activate().connect(sigc::ptr_fun(&on_quitInvoke),true);
    wndMain->signal_delete_event().connect(sigc::ptr_fun(&on_wndMainClose),true);
    
    /*Preferences*/
    mniPreferences->signal_activate().connect(sigc::ptr_fun(&on_preferencesInvoke),true);
    dlgPreferences->signal_delete_event().connect(sigc::ptr_fun(&on_preferencesClose),true);
    btnBrowseASMADir->signal_clicked().connect(sigc::mem_fun(*this,&GUI::on_btnBrowseASMADir),true);
    btnBrowseSTIL->signal_clicked().connect(sigc::mem_fun(*this,&GUI::on_btnBrowseSTIL),true);
    
    /*Channel mutes*/
    for(int i=0;i<8;i++) {
        chbChannelMutes[i]->signal_toggled().connect(sigc::ptr_fun(&on_channelMuteChange),true);
    }
    
    
    /*Playlist*/
    mniAddFileToPlaylist->signal_activate().connect(sigc::ptr_fun(&on_addFileToPlaylist),true);
    mniAddDirectoryToPlaylist->signal_activate().connect(sigc::ptr_fun(&on_addDirectoryToPlaylist),true);
    trvPlaylist->signal_row_activated().connect(sigc::ptr_fun(&on_playlistItemActivated),true);
    mniSavePlaylist->signal_activate().connect(sigc::ptr_fun(&on_savePlaylist),true);
    mniLoadPlaylist->signal_activate().connect(sigc::ptr_fun(&on_loadPlaylist),true);
    mniAddPlayerFile->signal_activate().connect(sigc::ptr_fun(&on_addPlayerFile),true);
    
    mniPlaylistSelectAll->signal_activate().connect(sigc::mem_fun(*this,&GUI::on_playlistSelectAll),true);
    mniPlaylistSelectNone->signal_activate().connect(sigc::mem_fun(*this,&GUI::on_playlistSelectNone),true);
    mniPlaylistSelectInvert->signal_activate().connect(sigc::mem_fun(*this,&GUI::on_playlistSelectInvert),true);

    
    mniPlaylistRemoveAll->signal_activate().connect(sigc::ptr_fun(&on_removeAllFromPlaylist),true);
    mniPlaylistRemoveSelected->signal_activate().connect(sigc::ptr_fun(&on_removeSelectedFromPlaylist),true);
    mniPlaylistTrimSelected->signal_activate().connect(sigc::ptr_fun(&on_trimPlaylistSelection),true);
    mniPlaylistPurge->signal_activate().connect(sigc::ptr_fun(&on_purgePlaylist),true);
    
    vbxPlaylist->signal_drag_data_received().connect(sigc::ptr_fun(&on_playlistDrop),true);
}

void GUI::updateAfterSAPLoad(Glib::ustring filename,int songNumber,int songCount,int duration,Glib::ustring info) {
    
    /*Update file name label*/
    lblFilename->set_text(filename);
    
    /*Update tune info and tip*/
    txvTuneInfo->get_buffer()->set_text(info);
    toolTips.set_tip(*lblFilename,info);
    
    
    /*Update counters*/
    updateAfterSubsongChange(songNumber,songCount,duration);
    
    
}

void GUI::updateAfterSubsongChange(int songNumber,int songCount,int duration) {
   
    if (duration>0) {
        hscSeeking->set_range(0,duration);
        hscSeeking->set_sensitive(true);
    }
    else {
        hscSeeking->set_sensitive(false);
    }
    
    /*Update song counter*/
    char buf[16];
    memset(buf,0,16);
    snprintf(buf,10,"%d/%d",songNumber+1,songCount);
    lblSongCounter->set_text(buf);
    
    /*Reset seek scale*/
    resetSeekScale();
}


void GUI::updateTick(int minutes,int seconds,int totalMiliseconds) {
    
    /*Elapsed time mm:ss*/
    char buf[16];
    memset(buf,0,16);
    snprintf(buf,10,"%02d : %02d",minutes,seconds);
    lblElapsedTime->set_text(buf);
    
    /*Elapsed time into HScale, if possible*/
    
    if (tickUpdateBlocked==false && totalMiliseconds>0) {
        hscSeekingConnection.disconnect();
        hscSeeking->set_value((double)totalMiliseconds);
        hscSeekingConnection=hscSeeking->signal_value_changed().connect(sigc::ptr_fun(&on_seek),true);
    }
    
}

void GUI::resetSeekScale() {
    hscSeeking->set_value(0);
}

void GUI::resetVisualization() {
    for (int i=0;i<8;i++) {
        prbChans[i]->set_fraction(0.0f);
    }
}

void GUI::resetPlayer() {
    resetSeekScale();
    lblElapsedTime->set_text("");
    lblSongCounter->set_text("");
    lblFilename->set_text("");
    resetVisualization();
}

void GUI::runMessageDialog(Glib::ustring title,Glib::ustring mainText,Glib::ustring text) {
    Gtk::MessageDialog msg(mainText,false,Gtk::MESSAGE_WARNING);
    msg.set_modal(true);
    msg.set_secondary_text(text);
    msg.set_title(title);
    msg.set_transient_for(*wndMain);
    msg.run();
    msg.hide();
}

void GUI::updatePreferencesChanged(Preferences* prefs,bool startup) {
    
    /*Repeat mode*/
    switch(prefs->getRepeatMode()) {
        case REPEAT_NO_PROGRESS: { mniRepNothing->set_active(true);break;}
        case REPEAT_SUBSONG: { mniRepSubsong->set_active(true);break;}
        case REPEAT_TUNE: { mniRepTune->set_active(true);break;}
        case REPEAT_PLAYLIST: { mniRepPlaylist->set_active(true);break;}
    }
    /*Silence detector*/
    hscSilenceLimit->set_value((double)prefs->getSilenceLimit());
    
    /*Default directory*/
    bool b = prefs->getUseDefaultDirectory();
    chbUseDefaultDirectory->set_active(b);
    entDefaultDirectory->set_text(prefs->getDefaultDirectory());
    
    if (startup==true && b==true) {

        /*Setup directories that exist and are directories*/

        /*Tune loading dialog*/
        if (g_file_test(prefs->getDefaultDirectory().c_str(),G_FILE_TEST_IS_DIR)==TRUE) {
            fcdLoad->set_current_folder(prefs->getDefaultDirectory());
            fcdAddToPlaylist->set_current_folder(prefs->getDefaultDirectory());
            fcdBrowseAndPlay->set_current_folder(prefs->getDefaultDirectory());
        }
    }
    
    /*Always first subsong*/
    b= prefs->getAlwaysFirstSubsong();
    chbAlwaysFirstSubsong->set_active(b);
    
    /*Normalize SAP header*/
    b = prefs->getNormalizeSAPHeader();
    chbNormalizeSAPHeader->set_active(b);
    
    /*Visualization period*/
    spbVisualizationPeriod->set_value((double)prefs->getVisualizationPeriod());
    
    /*Visualization synchro*/
    hscVisualizationSynchro->set_value((double)prefs->getVisualizationSynchro());
    
    /*Visualization decrement*/
    spbVisualizationDecrement->set_value((double)prefs->getVisualizationDecrement());
    
    /*Advanced controls*/
    if (startup==true) {
        if (prefs->getAdvancedControlsShownByDefault()==true) {
            tgbAdvancedControls->set_active(true);
        }
    }
    chbAdvancedControlsShownByDefault->set_active(prefs->getAdvancedControlsShownByDefault());
    
    /*ASMA support*/
    entAsmaDirectory->set_text(prefs->getAsmaDirectory());
    entStilFile->set_text(prefs->getStilFile());
    chbUseStil->set_active(prefs->getUseStilFile());
    
    /*ALSA*/
    entAlsaDevice->set_text(prefs->getAlsaDevice());
    chbAlwaysStereo->set_active(prefs->getAlwaysStereo());
    
    
}

void GUI::flushPreferences(Preferences* prefs) {
    /*Silence detector*/
    prefs->setSilenceLimit((int)hscSilenceLimit->get_value());
    /*Default directory*/
    prefs->setUseDefaultDirectory(chbUseDefaultDirectory->get_active());
    prefs->setDefaultDirectory(entDefaultDirectory->get_text());
    /*Always first subsong*/
    prefs->setAlwaysFirstSubsong(chbAlwaysFirstSubsong->get_active());
    /*Normalize SAP header*/
    prefs->setNormalizeSAPHeader(chbNormalizeSAPHeader->get_active());
    /*Visualization period*/
    prefs->setVisualizationPeriod(spbVisualizationPeriod->get_value_as_int());
    /*Visualization synchro*/
    prefs->setVisualizationSynchro((int)hscVisualizationSynchro->get_value());
    /*Visualization decrement*/
    prefs->setVisualizationDecrement(spbVisualizationDecrement->get_value_as_int());
    
    /*Advanced controls shown by default*/
    prefs->setAdvancedControlsShownByDefault(chbAdvancedControlsShownByDefault->get_active());
    
    /*ASMA*/
    prefs->setAsmaDirectory(entAsmaDirectory->get_text());
    prefs->setStilFile(entStilFile->get_text());
    prefs->setUseStilFile(chbUseStil->get_active());
    
    /*ALSA*/
    prefs->setAlsaDevice(entAlsaDevice->get_text());
    prefs->setAlwaysStereo(chbAlwaysStereo->get_active());
    
}


void GUI::updateVisualization(int* volumes) {
    
    double d=0;
    
    for(int i=0;i<8;i++) {
        d=((double)*(volumes+i))/256;
        prbChans[i]->set_fraction(d);
    }
}

void GUI::setVersionString(const char* versionString) {
    lblVersion->set_label(Glib::ustring(versionString));
}



bool GUI::on_hscSeekingButtonPressed(GdkEventButton* btn) {
   tickUpdateBlocked=true;
   return false;
}
bool GUI::on_hscSeekingButtonReleased(GdkEventButton* btn) {
    tickUpdateBlocked=false;
    return false;
}

void GUI::on_playlistSelectAll() {
    trvPlaylist->get_selection()->select_all();
}
void GUI::on_playlistSelectNone() {
    trvPlaylist->get_selection()->unselect_all();
}
void GUI::on_playlistSelectInvert() {
    Gtk::TreeModel::Children ch = trvPlaylist->get_model()->children();
    Gtk::TreeModel::iterator iter = ch.begin();
    
    Glib::RefPtr<Gtk::TreeSelection> selection=trvPlaylist->get_selection();
    
    while(iter!=ch.end()) {
        if (selection->is_selected(*iter)==true) {
            selection->unselect(*iter);
        }
        else {
            selection->select(*iter);
        }
        iter++;
    }
}

void GUI::on_btnBrowseASMADir() {
    int k=0;
    Gtk::FileChooserDialog asmaFcd("ASMA directory",Gtk::FILE_CHOOSER_ACTION_SELECT_FOLDER);

    asmaFcd.select_filename(entAsmaDirectory->get_text());

    asmaFcd.add_button(Gtk::Stock::CANCEL,Gtk::RESPONSE_CANCEL);
    asmaFcd.add_button(Gtk::Stock::OK,Gtk::RESPONSE_OK);
    k=asmaFcd.run();

    if (k==Gtk::RESPONSE_OK) {
        entAsmaDirectory->set_text(asmaFcd.get_filename());
    }

    
}

void GUI::on_btnBrowseSTIL() {
    int k=0;
    Gtk::FileChooserDialog stilFcd("STIL FILE",Gtk::FILE_CHOOSER_ACTION_OPEN);

    stilFcd.select_filename(entStilFile->get_text());

    stilFcd.add_button(Gtk::Stock::CANCEL,Gtk::RESPONSE_CANCEL);
    stilFcd.add_button(Gtk::Stock::OK,Gtk::RESPONSE_OK);
    k=stilFcd.run();

    if (k==Gtk::RESPONSE_OK) {
        entStilFile->set_text(stilFcd.get_filename());
    }
    
}

void GUI::setupPlaylistView(Gtk::TreeModelColumn<bool> *tmc0,Gtk::TreeModelColumn<Glib::ustring> *tmc1,Glib::RefPtr<Gtk::ListStore> model) {
    
    static Gtk::TreeViewColumn tvc0("0",*tmc0);
    static Gtk::TreeViewColumn tvc1("1",*tmc1);
    
    tvc0.set_sizing(Gtk::TREE_VIEW_COLUMN_FIXED);
    tvc1.set_sizing(Gtk::TREE_VIEW_COLUMN_FIXED);
    
    tvc0.set_fixed_width(25);
    
    trvPlaylist->append_column(tvc0);
    trvPlaylist->append_column(tvc1);
    
    Gtk::CellRenderer* cr = trvPlaylist->get_column_cell_renderer(0);
    Gtk::CellRendererToggle* crt = (Gtk::CellRendererToggle*)cr;
    crt->set_radio();
    crt->set_active(false);
    
    trvPlaylist->set_model(model);
    trvPlaylist->get_selection()->set_mode(Gtk::SELECTION_MULTIPLE);
    
}

