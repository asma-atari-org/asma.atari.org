-----------------------------------------------------------------------------
GENERAL NOTES:
-----------------------------------------------------------------------------

        Welcome to SAPER, a free, open source sap player for Linux and
  Windows. In case of any quastions, suggestions and bug reports feel free to
  mail to madqba@atari.pl. You are also welcome to check my website :-).

  SAPER makes use of the following:
        * SAP library v1.54 by Adam Bienias
        * STILView by LaLa

  Saper Home Page:
  http://www.saper.atari.pl

-----------------------------------------------------------------------------
OPTIONAL STUFF:
-----------------------------------------------------------------------------

  ASMA

-----------------------------------------------------------------------------
USAGE:
-----------------------------------------------------------------------------

  saper <file to play>
  You can also start saper without any parameters and use
  drag'n'drop mechanism to load music, or use standard file
  requester (note that You only have to highlight file to
  start playing).
