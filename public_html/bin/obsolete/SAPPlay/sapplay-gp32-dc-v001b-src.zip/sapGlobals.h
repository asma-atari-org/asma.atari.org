#ifdef __MAIN_DECLARATIONS__
#define axeEXTERN
#else
#define axeEXTERN extern
#endif

#ifndef BYTE
#define BYTE unsigned char
#endif
#ifndef WORD
#define WORD unsigned short
#endif
#ifndef DWORD
#define DWORD unsigned long
#endif
#ifndef BOOL
#define BOOL int
#endif
#define TRUE 1
#define FALSE 0

axeEXTERN bool	isStereo;
axeEXTERN int	sampleStep;

extern void pokeyGenerateCheckIRQline(void);
extern void pokeyGenerateIRQ( BYTE irqMask );

axeEXTERN BYTE	atariMem[ 0x10000 ];
axeEXTERN WORD	sndBuf[16384];
axeEXTERN int	sndBufPtr;

axeEXTERN BYTE	ANTIC_VCOUNT_D40B;

axeEXTERN WORD cpuReg_PC;
axeEXTERN BYTE cpuFlag_N,cpuFlag_Z,cpuFlag_C,cpuFlag_D,cpuFlag_B,cpuFlag_I,cpuFlag_V,cpuReg_A,cpuReg_X,cpuReg_Y,cpuReg_S;
// cpuFlag_N is valid only in last bit-7
// cpuFlag_Z is set if whole cpuFlag_Z is not zero
// cpuFlag_C is valid only in first bit-0
// cpuFlag_D is valid only in first bit-0
// cpuFlag_B is valid only in first bit-0
// cpuFlag_I is valid only in first bit-0
// cpuFlag_V is valid only in first bit-0


extern void cpuInit( void );
extern int cpuExecuteOneOpcode( void );
extern BYTE cpuGetFlags( void );
extern void cpuSetFlags( BYTE flags );

extern void pokeyInit( void );
extern void pokeyReset( void );
extern BYTE pokeyReadByte( short unsigned int address );
extern void pokeyWriteByte0( short unsigned int address, BYTE value );
extern void pokeyWriteByte1( short unsigned int address, BYTE value );
extern void pokeyUpdateSound( int n );
extern void pokeyUpdateSoundCounters( void );

inline BYTE freddieReadByte( WORD ad )
{
	if( (ad&0xF800)==0xD000 )
	{
		if( (ad&0xFF00)==0xD200 )
		{
			return pokeyReadByte( ad );
		}
		if( (ad&0xFF0F)==0xD40B )
			return ANTIC_VCOUNT_D40B;
	}
	return atariMem[ad];
}
inline BYTE freddieCPUReadByte( WORD ad )
{
	return atariMem[ad];
}

inline void freddieWriteByte( WORD ad, BYTE val )
{
	if( (ad&0xFF00)==0xD200 )
	{
		if( ((ad&0x10)==0) || (isStereo==false) ) pokeyWriteByte0( ad, val );
		else pokeyWriteByte1( ad, val );
		return;
	}
	atariMem[ad] = val;
}
axeEXTERN BYTE cpuVal,cpuNewVal;
axeEXTERN WORD cpuWorkAddress;
axeEXTERN BYTE doWrite;

/*
#pragma pack(push)
#pragma pack(1)
axeEXTERN union {
	struct {
		BYTE opcode;
		BYTE vb1;
		BYTE vb2;
		BYTE notUsed;
	};
	struct {
		BYTE opcode2;
		WORD valW;
		BYTE notUsed2;
	};
	DWORD dw;
} dword_u;
#pragma pack(pop)

#define DWORD_SET_DW(a) { dword_u.opcode=(a); dword_u.vb1=(a)>>8; dword_u.vb2=(a)>>16; dword_u.notUsed=(a)>>24; }
#define DWORD_GET_DW		(dword_u.opcode | (dword_u.vb1<<8) | (dword_u.vb2<<16) | (dword_u.notUsed<<24))
#define DWORD_SET_VALW(a) { dword_u.vb1=a; dword_u.vb2=a>>8; }
#define DWORD_GET_VALW (dword_u.vb1 | dword_u.vb2<<8)
#define DWORD_VB1 dword_u.vb1
#define DWORD_VB2 dword_u.vb2
*/

axeEXTERN BYTE dword_uu[4];
#define DWORD_SET_DW(a) { dword_uu[0]=(BYTE)(a); dword_uu[1]=(BYTE)((a)>>8); dword_uu[2]=(BYTE)((a)>>16); dword_uu[3]=(BYTE)((a)>>24); }
#define DWORD_GET_DW		((DWORD)((dword_uu[0]&0xff) | ((dword_uu[1]&0xff)<<8) | ((dword_uu[2]&0xff)<<16) | ((dword_uu[3]&0xff)<<24)))
#define DWORD_SET_VALW(a) { dword_uu[1]=(BYTE)a; dword_uu[2]=(BYTE)(a>>8); }
#define DWORD_GET_VALW ((WORD)((dword_uu[1]&0xff) | ((dword_uu[2]&0xff)<<8)))
#define DWORD_VB1 dword_uu[1]
#define DWORD_VB2 dword_uu[2]

#define ATARIMEM_GETW(a)  (atariMem[a] | (atariMem[(a)+1]<<8))

//typedef int (*opcodeFunc)(bool &holded);
typedef int (*opcodeFunc)(void);


extern opcodeFunc opcodes_0x00_0xFF[256];
