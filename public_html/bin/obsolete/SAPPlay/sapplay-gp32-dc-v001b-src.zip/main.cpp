#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "fred.h"
#include "sdl/sdl.h"

#include "sapLib.h"
#include "sapGlobals.h"

sapMUSICstrc * sap;

static void mixcallback ( void * userdata, Uint8 * stream, int len )
  {
		sapRenderBuffer( (short int*)stream, len/4 );
	}

int main ( int argc, char * argv[] )
	{
		unsigned char * mem;
    SDL_AudioSpec audioSpec;

    if ( SDL_Init ( SDL_INIT_AUDIO ) < 0 )
      {
        fprintf(stderr,"Couldn't initialize SDL\n");
        return 1;
      }
    atexit ( SDL_Quit );

		sap = sapLoadMusicFile( sapsong, sizeof(sapsong) );
		if (sap==NULL)
			{
				printf("Couldn't load SAP file\n");
				return 1;
			}

    /* Init SDL audio */
    audioSpec.freq = 44100;
    audioSpec.format = AUDIO_U16;
    audioSpec.channels = 2;
    audioSpec.samples = (audioSpec.freq/1);
    audioSpec.callback = mixcallback;
    audioSpec.userdata = (void*)sap;
    if (SDL_OpenAudio(&audioSpec,NULL)<0)
      {
        fprintf(stderr,"Error while opening audio device\n");
        return 1;
      }
    SDL_PauseAudio(0);

    while(1);

		return 0;
	}
