SAPPlay v0.01b (Dreamcast)
--------------------------

This player was written in 2003 by Christian Nowak <chnowak@web.de>
and is based on Adam Bienias' SAP Library v1.54. Visit
http://asma.dspaudio.com/ for more information. SAP files are Atari
XL/XE music files, pretty similar to C64 SID music files.

Usage:
Scramble sapplay.bin, rename it to 1ST_READ.BIN and burn a CD with this
file being in the root directory. You can place your SAP files wherever
you want on the CD. When you start the program, you must select an SAP
file in the file requester. When the music is playing, the buttons are
mapped as follows:

DPad left: Previous subsong
DPad right: Next subsong
DPad up: Restart current subsong
Start: Load another music file

In the file requester, the buttons are mapped as follows:

DPad up: One directory entry up
DPad down: One directory entry down
DPad left: 15 directory entries up
DPad right: 15 directory entries down
X: Parent directory
B: Cancel file requester
A: Select current file/directory

Keep in mind that this port was made in rush, so it might be pretty
buggy.

Have fun.
Christian Nowak a.k.a. CHN
chnowak@web.de
http://chn.roarvgm.com/

