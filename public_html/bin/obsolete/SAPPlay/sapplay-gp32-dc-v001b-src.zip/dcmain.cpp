#include <kos.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "dc/filereq.h"
#include "sapLib.h"

#define u8 unsigned char
#define u16 unsigned short
#define BOOL int
#define TRUE 1
#define FALSE 0

BOOL paused=FALSE;
u16 sndbuffer[65536];
u32 palette[256];
u8 * screenbuf;

#define COPYSCREENBUF \
	{ \
		int i; \
		for (i=0;i<640*480;i++) \
     	vram_l[i] = palette[screenbuf[i]]; \
  }

void SetPaletteEntry ( u8 i, u8 r, u8 g, u8 b )
	{
		palette[i] = (r<<16) | (g<<8) | b;
	}

void * snd_callback(int req, int * ret)
	{
		if (paused)
			{
		  	int i;
		  	for (i=0;i<req>>1;++i)
		  		sndbuffer[i] = 0x8000;
			} else
			{
				sapRenderBuffer( (short int*)sndbuffer, req/4 );
    	}

    *ret = req;

		return sndbuffer;
	}

void sndstart(void)
	{
 		snd_stream_init (snd_callback);
		snd_stream_start(44100, 1);
	}

void sndstop(void)
	{
		snd_stream_stop();
	}

u16 pollpad ( void )
	{
		u8 cont;
		u16 retval=0;

		cont = maple_first_controller();
		if (cont)
			{
				cont_cond_t ctrl;

				while (cont_get_cond ( cont, &ctrl ) < 0);
				
				retval |= (!(ctrl.buttons&CONT_DPAD_UP))    ? 1  : 0;
				retval |= (!(ctrl.buttons&CONT_DPAD_DOWN))  ? 2  : 0;
				retval |= (!(ctrl.buttons&CONT_DPAD_LEFT))  ? 4  : 0;
				retval |= (!(ctrl.buttons&CONT_DPAD_RIGHT)) ? 8  : 0;
				retval |= (!(ctrl.buttons&CONT_START)) ? 16 : 0;
/*
				if (!(ctrl.buttons&CONT_X))
					{
						printf("exit\n");
						exit(0);
					}*/
			}
		return retval;
	}

int main(int argc, char **argv)
	{
		int curSong;
		int numSongs;
		int sapsize;
		int fnameofs=0;
		u8 * sapmem;
		char fname[512];
		char fnamecopy[512];
		sapMUSICstrc * sap;
		BOOL saploaded=FALSE;
		int i;
		char bla[32];

		paused = TRUE;		
		screenbuf = (u8*)malloc(640*480);

		vid_set_mode(DM_640x480, PM_RGB888);

		SetPaletteEntry ( 1, 255, 255, 255 );
		SetPaletteEntry ( 0, 0, 0, 0 );
		SetPaletteEntry ( 2, 255, 0, 0 );
		SetPaletteEntry ( 3, 0, 0, 255 );

		do
			{
				do
					{
						FSEL fsel;

   					fsel.fname = fname;
   					fsel.palette = palette;
	  				fsel.bgcolor = 0;
	  				fsel.filecolor = 1;
	  				fsel.dircolor = 3;
						fsel.curdircolor = 2;
						if (saploaded)
							fsel.fnamepreselect = fnamecopy;
						else
							fsel.fnamepreselect = NULL;
	  				if (FileRequest ( &fsel, "/", saploaded && sap!=NULL )==0)
							{
								file_t fh;
								fh = fs_open ( fname, O_RDONLY );
								if (fh)
									{
										fs_seek ( fh, 0, SEEK_END );
										sapsize = fs_tell ( fh );
										fs_seek ( fh, 0, SEEK_SET );
		
										sapmem = (u8*)malloc(sapsize);
										fs_read ( fh, sapmem, sapsize );
			
										fs_close ( fh );
		
										sap = sapLoadMusicFile( sapmem, sapsize );
		
										free ( sapmem );

										if (sap)
											{
												saploaded=TRUE;
												strcpy(fnamecopy, fname);
												for (i=strlen(fnamecopy)-1;i>=0;i--)
												if (fnamecopy[i]=='/') break;
												fnameofs=i+1;
        								curSong = sap->defSong;
        								numSongs = sap->numOfSongs;
        								if (curSong<0) curSong=-curSong;
        								if (numSongs<0) numSongs=-numSongs;
											}
									}
							}
					} while(sap==NULL);

				paused = FALSE;
				sndstart();

				while(1)
					{
						u16 k;
						for (i=0;i<640*480;i++)
							screenbuf[i]=0;

						amiga_textout ( screenbuf, "SAPPlay DC v0.01b", 16, 0+16, 1, 0, FALSE );
						amiga_textout ( screenbuf, "2003 by Christian Nowak <chnowak@web.de>", 16, 16+16, 1, 0, FALSE );
						amiga_textout ( screenbuf, "SAP Library ver.1.54 by Adam Bienias", 16, 32+16, 1, 0, FALSE );
						sprintf(bla,"Now playing: %s", &fname[fnameofs]);
						amiga_textout ( screenbuf, bla, 16, 64+16, 1, 0, FALSE );
						sprintf(bla,"Song %d/%d", curSong, numSongs);
						amiga_textout ( screenbuf, bla, 16, 80+16, 1, 0, FALSE );
						COPYSCREENBUF;

						while(!((k=pollpad())&16))
							{
								snd_stream_poll();
								if ( (k&4) && (curSong>1) )
									{
										sndstop();
										curSong--;
										sapPlaySong(curSong-1);
										while (pollpad()&4);
										sndstart();
										break;
									} else
								if ( (k&8) && (curSong<numSongs) )
									{
										sndstop();
										curSong++;
										sapPlaySong(curSong-1);
										while (pollpad());
										sndstart();
										break;
									} else
								if ( k&1 )
									{
										sndstop();
										sapPlaySong(curSong-1);
										while (pollpad()&1);
										sndstart();
									}
							}
						if (k&16) break;
					}
				sndstop();

			} while(1);
		return 0;
	}
