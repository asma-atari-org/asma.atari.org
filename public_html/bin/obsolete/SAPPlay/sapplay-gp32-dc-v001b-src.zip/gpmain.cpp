#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "gpsdk/gpsdk.h"
#include "gpmm.h"
#include "sapLib.h"

GPDRAWSURFACE gpDraw[2];
BOOL paused=FALSE;

/* Converts 8bit rgb values to a GP32 palette value */
#define GP_RGB24(r,g,b) (((((r>>3))&0x1f)<<11)|((((g>>3))&0x1f)<<6)|((((b>>3))&0x1f)<<1))

/* Sets a single GP32 palette entry */
void GpSetPaletteEntry ( u8 i, u8 r, u8 g, u8 b )
  {
    GP_PALETTEENTRY entry = GP_RGB24(r,g,b);
    GpPaletteEntryChange ( i, 1, &entry, 0 );
  }

void mixercallback ( void * userdata, u8 * stream, int len )
	{
		if (!paused)
			sapRenderBuffer( (short int*)stream, len/4 );
		else
			{
				int i;
				
				for (i=0;i<len/2;i++)
					((u16*)stream)[i]=32768;
			}
	}

void GpMain ( void * arg )
	{
		sapMUSICstrc * sap;
    GPSOUNDBUF sb;
    char bla[32];
    char fnamecopy[256];
		u8 * sap_mem;
		int sap_size;
		int curSong;
		int numSongs;
		BOOL sap_loaded = FALSE;
		int fnameofs=0;

/*		GpClockSpeedChange (66000000, 0x3a012, 0);*/
/*		GpClockSpeedChange (80000000, 0x48012, 1);*/
		GpClockSpeedChange (132000000, 0x3a011, 3);
    /* Initialize the LCD */
    GpGraphicModeSet(8, NULL);
    GpLcdSurfaceGet(&gpDraw[0], 0);
    GpLcdSurfaceGet(&gpDraw[1], 1);
    GpSurfaceSet(&gpDraw[0]);
    GpLcdEnable();
    GpFatInit();
    GpKeyInit();

    GpRelativePathSet ( "gp:\\gpmm\\sap" );
    
    GpSetPaletteEntry(0,255,255,255);
    GpSetPaletteEntry(1,0,0,0);
    GpSetPaletteEntry(2,255,0,0);
    GpSetPaletteEntry(3,0,0,255);

    paused=TRUE;
   	sb.freq = PCM_S44;
		sb.format = PCM_16BIT;
		sb.samples = 44100/10;
		sb.userdata = NULL;
		sb.callback = mixercallback;
		sb.pollfreq = 12*(44100/sb.samples);
		GpSoundBufStart(&sb);

   	do
   		{
	   		int i,k;
	   		FSEL fsel;
	   		char fname[256];
	   		char tmp2[256];

	   		do
	   			{
		        fsel.bgcolor = 0;
        		fsel.dircolor = 3;
        		fsel.filecolor = 1;
        		fsel.dirselcolor = 2;
        		fsel.fileselcolor = 2;
        		fsel.curdircolor = 1;
        		fsel.fname = fname;
        		fsel.gpDraw = &gpDraw[0];
        		if (sap_loaded)
       				fsel.fnamepreselect = fnamecopy;
       			else
       				fsel.fnamepreselect = NULL;
        		GpRelativePathGet ( tmp2 );
        		if (FileRequest ( &fsel, NULL, sap_loaded && sap!=NULL )==0)
        			{
	        			FILE * fh;
	        			fh = fopen (fname, "rb");
	        			if (fh!=NULL)
	        				{
		        				if (sap_loaded)
		        					free(sap_mem);
		        				fseek(fh, 0, SEEK_END);
		        				sap_size=ftell(fh);
		        				fseek(fh, 0, SEEK_SET);
		        				sap_mem=(u8*)malloc(sap_size);
		        				fread(sap_mem, sap_size, 1, fh);
		        				fclose(fh);
										sap = sapLoadMusicFile( sap_mem, sap_size );
										if (sap!=NULL)
											{
												sap_loaded=TRUE;
												strcpy(fnamecopy, fname);
												for (i=strlen(fnamecopy)-1;i>=0;i--)
													if (fnamecopy[i]=='\\') break;
												fnameofs=i+1;
        								curSong = sap->defSong;
        								numSongs = sap->numOfSongs;
        								if (curSong<0) curSong=-curSong;
        								if (numSongs<0) numSongs=-numSongs;
											}
	        				}
        			}
        	} while(sap==NULL);

        paused=FALSE;

	   		while(1)
	   			{
			   		for (i=0;i<320*240;i++)
	   					gpDraw[0].ptbuffer[i]=0;

	   				GpTextOut (NULL, &gpDraw[0], 0, 0,  "SAPPlay GP32 v0.01b", 1);
	   				GpTextOut (NULL, &gpDraw[0], 0, 16, "2003 by Christian Nowak <chnowak@web.de>", 1);
	   				GpTextOut (NULL, &gpDraw[0], 0, 32, "SAP Library ver.1.54 by Adam Bienias", 1);
	   				sprintf(bla, "Now playing: %s", &fnamecopy[fnameofs]);
	   				GpTextOut (NULL, &gpDraw[0], 0, 64, bla, 1);
	   				sprintf(bla, "Song %d/%d", curSong, numSongs);
	   				GpTextOut (NULL, &gpDraw[0], 0, 80, bla, 1);

	   				while(!((k=GpKeyGet())&GPC_VK_SELECT))
	   					{
	   						if (k&GPC_VK_FL)
	   							GpAppExit();
	   						else
	   						if ( (k&GPC_VK_LEFT) && (curSong>1) )
	   							{
		   							paused=TRUE;
		   							curSong--;
		   							sapPlaySong(curSong-1);
		   							paused=FALSE;
		   							while (GpKeyGet()&GPC_VK_LEFT);
		   							break;
	   							} else
	   						if ( (k&GPC_VK_RIGHT) && (curSong<numSongs) )
	   							{
		   							paused=TRUE;
		   							curSong++;
		   							sapPlaySong(curSong-1);
		   							paused=FALSE;
		   							while (GpKeyGet()&GPC_VK_RIGHT);
		   							break;
	   							} else
	   						if ( k&GPC_VK_UP )
	   							{
		   							paused=TRUE;
		   							sapPlaySong(curSong-1);
		   							paused=FALSE;
		   							while (GpKeyGet()&GPC_VK_UP);
	   							}
   						}
   					if (k&GPC_VK_SELECT) break;
   				}

/*	   		GpSoundBufStop();*/
				paused=TRUE;
   		} while(1);

		while(!(GpKeyGet()&GPC_VK_FL));GpAppExit();
	}
