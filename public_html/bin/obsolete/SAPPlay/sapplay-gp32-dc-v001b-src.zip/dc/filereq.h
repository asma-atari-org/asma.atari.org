/* Dreamcast file selector
 * Written 2002,2003 by Christian Nowak <chnowak@web.de>
 * http://chn.roarvgm.com/
 */

#ifndef __FILEREQ_H__
#define __FILEREQ_H__

#include "defines.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct FSEL
	{
		char * fname;
		u32 * palette;
		u8 bgcolor;
		u8 filecolor;
		u8 dircolor;
		u8 curdircolor;
		char * fnamepreselect;
		char * dir;
		char * file;
	} FSEL;

void amiga_textout ( u8 * buffer, char * t, unsigned int x, unsigned int y, u8 fgcolor, u8 bgcolor, BOOL reverse );
int FileRequest ( FSEL * fsel, char * startdir, BOOL exitable );

#ifdef __cplusplus
}
#endif

#endif
