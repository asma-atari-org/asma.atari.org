/* Dreamcast file selector
 * Written 2002,2003 by Christian Nowak <chnowak@web.de>
 * http://chn.roarvgm.com/
 */

#include <kos.h>
#include "defines.h"
#include "filereq.h"
#include "amigafont.h"

uint16 GetButtons(u8 cont)
	{
	  cont_cond_t ctrl;
   	while (cont_get_cond ( cont, &ctrl ) < 0);
   	return ~ctrl.buttons;
  }

static int searchlastchar ( char * str, char c )
	{
		int l=-1;
		int i=0;
		
		while(1)
			{
				if (str[i]=='\0')
					return l;
				else if (str[i]==c)
					l = i;
				
				i++;
			}
		
		return l;
	}

static void strupper ( char * str )
	{
		int i;
		
		for (i=0;i<strlen(str);i++)
			str[i] = toupper ( str[i] );
	}

void amiga_charout ( u8 * buffer, char d, unsigned int x, unsigned int y, u8 fgcolor, u8 bgcolor, BOOL reverse )
	{
		unsigned int i,j;
		unsigned int fontoffs;
		u8 c = d;
		u8 * b = &buffer[(vid_mode->width*y)+x];
		
		if (reverse)
			{
				u8 temp = fgcolor;
				fgcolor = bgcolor;
				bgcolor = temp;
			}
		
		fontoffs = ((unsigned int)c)<<4;
		
		for (i=j=0;i<16;i++,j+=vid_mode->width)
			{
				int k;
				u8 cl = amigafont[fontoffs+i];
        b[j+0] = cl & 0x80 ? fgcolor:bgcolor;
        b[j+1] = cl & 0x40 ? fgcolor:bgcolor;
        b[j+2] = cl & 0x20 ? fgcolor:bgcolor;
        b[j+3] = cl & 0x10 ? fgcolor:bgcolor;
        b[j+4] = cl & 0x08 ? fgcolor:bgcolor;
        b[j+5] = cl & 0x04 ? fgcolor:bgcolor;
        b[j+6] = cl & 0x02 ? fgcolor:bgcolor;
        b[j+7] = cl & 0x01 ? fgcolor:bgcolor;
			}
	}

void amiga_textout ( u8 * buffer, char * t, unsigned int x, unsigned int y, u8 fgcolor, u8 bgcolor, BOOL reverse )
	{
		int i,l;
		
		l=strlen(t);
		for (i=0;i<l;i++)
			amiga_charout ( buffer, t[i], x+(i<<3), y, fgcolor, bgcolor, reverse );
	}

static int getNumDirEntries ( char * dir )
	{
		file_t fh;
		char dname[256];
		int numdir;
		
		strcpy (dname, "/cd");
		strcat (dname, dir);
		
		if ((fh=fs_open(dname, O_DIR|O_RDONLY))==0)
			return -1;

		for (numdir=0;fs_readdir(fh)!=NULL;numdir++);

		fs_close ( fh );
		
		return numdir;
	}

static int readDirectory ( char * dir, dirent_t ** directory )
	{
		int i;
		int numentries = getNumDirEntries ( dir );
		file_t fh;
		char dname[256];
		
		strcpy (dname, "/cd");
		if (dir[0] != '/')
			strcat (dname, "/");
		strcat (dname, dir);

		if (numentries==-1)
			return -1;
		
		if ((fh=fs_open(dname, O_DIR|O_RDONLY))==0)
			return -1;

		*directory = calloc ( sizeof(dirent_t), numentries );
		
		for (i=0;i<numentries;i++)
			{
				dirent_t * entry = fs_readdir ( fh );
				if (entry==NULL)
					break;
				memcpy ( &((*directory)[i]), entry, sizeof(dirent_t) );
			}
		
		fs_close ( fh );

		return i;
	}

static int showDir ( u8 * buf, FSEL * fsel, dirent_t ** pdirectory, int numentries, int index, char * dirname )
	{
		int i;
		int screen_start;
		int index_start;
		char str[129];
		int middle = vid_mode->height/(16*2);

		memset ( buf, fsel->bgcolor, vid_mode->width*vid_mode->height );
		if (index>=numentries)
			index=0;
			
		if (index>middle)
			{
				index_start = index-middle;
				screen_start = 0;
			} else
			{
				index_start = 0;
				screen_start = middle-index;
			}

		amiga_textout ( buf, dirname, 0, 0, fsel->curdircolor, fsel->bgcolor, FALSE );
		for (i=0;(i+screen_start)<((vid_mode->height/16)-1) && (i+index_start)<numentries;i++)
			{
				int res;
				char ts[64];
				int j;

				memset ( str, 0x20, 128 );
				str[vid_mode->width/8] = '\0';

				if (pdirectory[i+index_start]->size>=0)
					{
						sprintf(ts, "%d", pdirectory[i+index_start]->size);
						strcpy ( &str[(vid_mode->width/8)-strlen(ts)], ts );
					}
				memcpy ( str, pdirectory[i+index_start]->name, strlen(pdirectory[i+index_start]->name) );
				strupper ( str );
				amiga_textout ( buf, str, 0, (1+i+screen_start)*16, pdirectory[i+index_start]->size<0 ? fsel->dircolor:fsel->filecolor, fsel->bgcolor, (i+index_start)==index );
			}
		
    for (i=0;i<vid_mode->width*vid_mode->height;i++)
	   	vram_l[i] = fsel->palette[buf[i]];
	   
	  return 0;
	}

static int selectFile ( u8 * buf, FSEL * fsel, dirent_t ** pdirectory, int numentries, char * dirname, int startindex, BOOL exitable )
	{
		int index = startindex;
		int delay = 0;
		int oldindex = index;

		while (1)
			{
				uint8 cont;
        cont_cond_t ctrl;
        
	      cont = maple_first_controller();
        if (cont)
          {
	          uint16 buttons;
	          int i;

        		showDir ( buf, fsel, pdirectory, numentries, index, dirname );

/*        		if (numentries>0)
        			printf("%s\n", pdirectory[index]->name);*/
        			
        		if (delay>0)
        			{
	        			int w;
	        			uint16 k=-1;

	        			if (delay==1)
	        				for (w=0;w<50 && ((k=GetButtons(cont))!=0);w++)
	        					vid_waitvbl();
	        				
	        			if (k==0)
	        				delay=0;
	        			else
	        				delay++;
        			} else while (GetButtons(cont)!=0);

        		while ((buttons=GetButtons(cont))==0) delay=0;
        		
/*        		if (oldindex!=index)
        			{
		        		for (i=0;i<25;i++)
        					vid_waitvbl();
        			}*/

        		oldindex = index;
        		if (delay<2)
        			delay = 1;

            if ( buttons&CONT_DPAD_UP )
         			index--;
            else if ( buttons&CONT_DPAD_DOWN )
          		index++;
            else if ( buttons&CONT_DPAD_LEFT )
           		index -= vid_mode->height/(16*2);
            else if ( buttons&CONT_DPAD_RIGHT )
           		index += vid_mode->height/(16*2);
            else if ( buttons&CONT_A )
           		return index;
           	else if ( (buttons&CONT_B) && exitable )
           		return -2;
           	else if ( buttons&CONT_X )
           		return -1;
           	else delay = 0;

            if (index>=numentries)
            	index = numentries-1;
            if (index<0)
            	index = 0;
					}
			}
	}

static void parentDir ( char * dir )
	{
    int len = strlen ( dir )-1;
    int i;

    if (dir[len]=='/')
      len--;
    if (len<=0)
      return;

    for (i=len;i>=0;i--)
      {
        if (dir[i]=='/')
          break;
      }

    if (i==0)
      dir[i++] = '/';

    dir[i] = '\0';
	}

static void sortDirEntries ( dirent_t ** pdirlist, int num )
  {
    int i,j;

    if (num<2)
      return;

    for (i=0;i<num;i++)
      {
        for (j=0;j<num-1;j++)
          {
            if (strcmp(pdirlist[j]->name, pdirlist[j+1]->name)>0)
              {
                dirent_t * temp;
                temp = pdirlist[j];
                pdirlist[j] = pdirlist[j+1];
                pdirlist[j+1] = temp;
              }
          }
      }
  }

int FileRequest ( FSEL * fsel, char * startdir, BOOL exitable )
	{
    dirent_t * directory;
    dirent_t ** pdirectory;		
    u8 * buf;
    int i,j,num;
    char dir[256];
    char file[256];
    BOOL filesel;
    
		if (fsel->fnamepreselect!=NULL)
			{
				int l,i;
				
				l = searchlastchar ( fsel->fnamepreselect, '/' );
				if (l>3)
					{
						/* Get directory */
						strcpy ( dir, &fsel->fnamepreselect[3] );
						dir[l-2] = '\0';
						/* Get filename */
						strcpy ( file, &fsel->fnamepreselect[l+1] );
					} else
				if (l==3)
					{
						dir[0]='/';
						dir[1]='\0';
						strcpy ( file, &fsel->fnamepreselect[l+1] );
					}
			} else
			{
    		dir[0] = '\0';
    		if (startdir[0]!='/')
    			strcat ( dir, "/" );
				strcat ( dir, startdir );
			}
			
		fsel->dir = dir;
		fsel->file = file;

		buf = calloc ( vid_mode->width, vid_mode->height );

		filesel = fsel->fnamepreselect!=NULL;
		while (1)
			{
				int index=0;
				strupper ( dir );
    		if ((num=readDirectory(dir, &directory))!=-1)
    			{
	    			int numdirs;
	    			int startsel = 0;

	    			pdirectory = calloc ( sizeof(dirent_t*), num );
	    			for (i=0,numdirs=0;i<num;i++)
	    				{
		    				if ( (strcmp(directory[i].name,"..")!=0) &&
		    						 (strcmp(directory[i].name,".")!=0) )
		    					{
	    							pdirectory[i] = &directory[i];
	    							if (directory[i].size<0)
	    								numdirs++;
    							}
    					}

	    			/* Find index of last directory */
	    			j=0;
	    			while (j<num)
	    				{
		    				if (pdirectory[j]->size<0)
		    					j++;
		    				else
		    					break;
	    				}

	    			/* Separate dirs from files */
	    			for (i=j;i<num;i++)
	    				{
		    				if (pdirectory[i]->size<0)
		    					{
			    					dirent_t * tmp = pdirectory[i];
			    					pdirectory[i] = pdirectory[j];
			    					pdirectory[j] = tmp;
			    					j++;
		    					}
	    				}

	    			sortDirEntries(pdirectory, numdirs);								/* Sort Dirs */
	    			sortDirEntries(&pdirectory[numdirs], num-numdirs);	/* Sort Files */
	    			
	    			if (filesel && num>0)
	    				{
		    				startsel = 0;
		    				for (i=0;i<num;i++)
		    					{
			    					if (stricmp(pdirectory[i]->name, file)==0)
			    						startsel = i;
		    					}
	    				}
	    			
	    			index = selectFile ( buf, fsel, pdirectory, num, dir, filesel ? startsel : 0, exitable );

/*	    			if (index>=0)
	    				{
	    					printf ("Selected Entry\n");
	    					printf ("Size: %d\n", pdirectory[index]->size);
	    					printf ("Name: %s\n", pdirectory[index]->name);
    					}*/
    				filesel = FALSE;

	    			if (index==-1)	/* Parent */
	    				{
		    				int k,l;
		    				
		    				l = strlen(dir);
		    				if (l>1 && dir[l-1]=='/')
		    					dir[l-1]='\0';
		    				k = searchlastchar(dir, '/');
		    				if (k>=0)
		    					{
		    						filesel=TRUE;
		    						strcpy ( file, &dir[k+1] );
	    						}
		    				parentDir ( dir );
	    				} else
	    			if (index==-2)	/* Cancel */
	    				{
		    				free (directory);
		    				free (pdirectory);
		    				free (buf);
		    				return -1;
	    				} else
	    			if (num>0)
	    				{
	    					if (pdirectory[index]->size<0)
	    						{
		    						if (dir[strlen(dir)-1]!='/')
		    							strcat ( dir, "/" );
	    							strcat ( dir, pdirectory[index]->name );
	    							index = 0;
    							} else
    							{
	    							strcpy (fsel->fname, "/cd");
	    							if (dir[0]!='/')
	    								strcat (fsel->fname, "/");
	    							strcat (fsel->fname,dir);
	    							if (fsel->fname[strlen(fsel->fname)-1]!='/')
	    								strcat(fsel->fname, "/");
	    							strcat (fsel->fname, pdirectory[index]->name);
	    							strupper ( fsel->fname );
	    							free (directory);
	    							free (pdirectory);
	    							free (buf);
	    							return 0;
    							}
	    					free (directory);
	    					free (pdirectory);
    					}
    			} else
    			{
	    			free (buf);
    				return -1;
    			}
    	}
	}
