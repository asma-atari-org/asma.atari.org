SAPPlay v0.01b (GP32)
---------------------

This player was written in 2003 by Christian Nowak <chnowak@web.de>
and is based on Adam Bienias' SAP Library v1.54. Visit
http://asma.dspaudio.com/ for more information. SAP files are Atari
XL/XE music files, pretty similar to C64 SID music files.

Usage:
Copy sapplay.fxe to gp:\gpmm and all your SAP files to gp:\gpmm\sap. You
can create subdirectories there. When you start the program, you must
select a SAP file in the file requester. When the music is playing,
the buttons are mapped as follows:

Left shoulder: Reset GP32
DPad left: Previous subsong
DPad right: Next subsong
DPad up: Restart current subsong
Select: Load another music file

You can press the B button to cancel the file requester.

Keep in mind that this port was made in rush, so it might be pretty
buggy. It's also running at 133MHz for now as I was too lazy :o)

Have fun.
Christian Nowak a.k.a. CHN
chnowak@web.de
http://chn.roarvgm.com/

