
#ifndef SPCVIEW_H_
#define SPCVIEW_H_

#include <Be.h>
#include "constants.h"


class SapView : public BView

{

public:
	SapView(BRect rect);
	~SapView();
	void MessageReceived(BMessage *message);
	void AttachedToWindow(void);
	void StartP(void);

	static void BufferProc(void *the_cookie, void *buffer, size_t size, const media_raw_audio_format &format);


private:
	BPath path;
	entry_ref ref;
	BFilePanel *fOpenPanel;
	BButton *button;
	BStringView*textc;
	BButton *button1;
	BSoundPlayer *saplayer;
	int i;
};

#endif