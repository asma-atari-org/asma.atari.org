#ifndef SPWIN_H_
#define SPWIN_H_

#include <Be.h>
#include "sapview.h"

class SapWin : public BWindow
{

public:

	SapWin(BRect frame);
	bool QuitRequested();
	void MessageReceived(BMessage *msg);
private:
	SapView *sapview;
	BMenuBar *menubar;
	BMenu *menu;
	BMenuItem *item;
	



};


#endif