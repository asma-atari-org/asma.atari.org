#ifndef SPCAPP_H_
#define SPCAPP_H_

#include <Be.h>
#include "sapwin.h"

class SapApp : public BApplication

{
public:

	SapApp();

private:

	SapWin *sapwin;

};

#endif