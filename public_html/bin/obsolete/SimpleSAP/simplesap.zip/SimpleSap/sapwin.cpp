#include "sapwin.h"

SapWin::SapWin(BRect frame)
	:BWindow(frame, "SimpleSapPlayer", B_TITLED_WINDOW, B_WILL_DRAW)
	
	{
		menubar = new BMenuBar(Bounds(), "menu_bar");
		AddChild(menubar);
		
		menu = new BMenu("File");
		item = new BMenuItem("Open", new BMessage(MENU_FILE_OPEN), 'O');
		menu->AddItem(item);
		item = new BMenuItem("Quit", new BMessage(B_QUIT_REQUESTED), 'Q');
		menu->AddItem(item);
		menubar->AddItem(menu);
	
		sapview = new SapView(Bounds());
		sapview->SetViewColor(216,216,216);
		sapview->MakeFocus();
		AddChild(sapview);
	
	}
	

bool SapWin::QuitRequested()
{
	be_app->PostMessage(B_QUIT_REQUESTED);
	return(true);
}

void SapWin::MessageReceived(BMessage *msg)
{
		switch(msg->what) {
		
		case MENU_FILE_OPEN:
			sapview->MessageReceived(msg);
		break;
		
		default:
			BWindow::MessageReceived(msg);
		break;
	}
}
		


