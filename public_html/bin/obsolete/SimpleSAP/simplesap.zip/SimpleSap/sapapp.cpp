#include "sapapp.h"

SapApp::SapApp()
	:BApplication("application/x-vnd.SimpleSap")
	
	{
	BRect aRect(200,200,400,300);
	sapwin = new SapWin(aRect);
	sapwin->Show();
	}
	
int main()

	{
	SapApp sapapp;
	sapapp.Run();
	
	return(0);
	}