

#ifndef __CONSTANTS_H__
#define __CONSTANTS_H__

#define GO 'go'
#define MENU_FILE_OPEN 'OPEN'

#endif