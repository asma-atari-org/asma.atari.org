SAP Maker version 5.0
CMC,CMR,MPT,MD1,MD2,TMC,TM8,AMS -> SAP file converter
Programmed by Piotr Fusik <fox@scene.pl>
=====================================================

SAP Maker is for converting Atari 8-bit music files into the SAP (Slight
Atari Player) format, so they can be easily replayed on a PC using SAP Player,
SAP plug-in for Winamp or any of the several programs for playing SAP files.

Good news: this version of SAP Maker is more user-friendly!
And even better news: there is new SAP Maker Win which is even more
user-friendly!

There are two programs in this package: command-line SAP Maker (available
for Windows and Linux) and SAP Maker Win (Windows only).
Which one to use is your choice. They have same purpose, just different
user interface.

How to use SAP Maker
--------------------
For convenience, put sapmaker.exe into a directory
that is on your PATH. Start your command prompt. Type
sapmaker --help
for a list of supported options. You don't have to use the options, you can
just specify names of files to be converted. For example:
sapmaker *.cmc
will convert all CMC files in the current directory to the SAP format.
If you use options, place them BEFORE the name of the file to be converted.
There are options for specifying the AUTHOR, NAME and DATE tags in
the generated SAP file. For example:
sapmaker -a "Lukasz Sychowicz (X-Ray)" -n "Drunk Chessboard" druch.mpt
Note that -a and -d apply to all the files mentioned after them.

How to use SAP Maker Win
------------------------
First you must "install" it. This is done by simply running the application.
You will get a message that SAP Maker Win has been associated with some file
types. From now on, just double-click a file to converted it to the SAP
format. That's all! Newly created SAP file appears in the current directory.
If you want to convert many files from the Windows Explorer, select them,
right-click and choose Open. You may get a warning from Windows about opening
so many files at once.
Of course, if you want to specify the author, the name or the date, you have
to use the command-line SAP Maker.

History
-------

v1.0: ???
- Two hours fpr coding, testing and writing documentation total.
  Bad design and ugly code.

v2.0: 12th Dec 2000.
- Support for MPT modules with two digi channels.
  Use .MD2 extension for modules and .D8 for samples.
- Support for "CMC Rzog" modules with changed bass table.
  Just rename files to *.CMR.
- Samples relocated automatically if conficting with MD1/MD2.
- Changed coding style. Many spaces added.

v3.0: 9th Aug 2001.
- Support for MD1 modules with D8 samples.
  If no .D15 samples are found for a MD1 module, .D8 samples are read.

v4.0: 7th Feb 2002.
- Support for AMS modules.
- Display info file name if the file can not be opened.

v5.0: 15th Jan 2005.
- Rewritten everything from scratch (took more than 10 hours!).
- No more 'info file', everything is driven directly from the command-line.
- SAP Maker Win.
- Atari music player routines are built in the executable file. No more *.plr
  files.
- Number of subsongs in the CMC/CMR format is detected automatically
  by default. Subsongs are still not supported for the other formats.
- Support for broken MPT files because of a bug in MPT.
- Incorrect headers inside SAP files were generated for MD1/MD2. Fixed.

Credits
-------
Idea by Marcin 'Pigula' Prusisz and Jaroslaw 'Solo' Padula.
Atari music player routines (except for AMS, which is written by me)
by Marcin 'Jaskier' Lewandowski.
Programming and this text by Piotr '0xF' Fusik <fox@scene.pl>.

License
-------
SAP Maker and SAP Maker Win are freeware.
