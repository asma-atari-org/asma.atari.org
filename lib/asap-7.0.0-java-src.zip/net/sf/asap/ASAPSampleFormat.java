// Generated automatically with "fut". Do not edit.
package net.sf.asap;

/**
 * Format of output samples.
 */
public enum ASAPSampleFormat
{
	/**
	 * Unsigned 8-bit.
	 */
	U8,
	/**
	 * Signed 16-bit little-endian.
	 */
	S16_L_E,
	/**
	 * Signed 16-bit big-endian.
	 */
	S16_B_E
}
