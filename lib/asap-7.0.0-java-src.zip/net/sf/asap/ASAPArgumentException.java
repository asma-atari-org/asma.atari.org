// Generated automatically with "fut". Do not edit.
package net.sf.asap;

/**
 * Exception thrown when an invalid argument is passed.
 */
public class ASAPArgumentException extends Exception
{
	public ASAPArgumentException() { }
	public ASAPArgumentException(String message) { super(message); }
	public ASAPArgumentException(String message, Throwable cause) { super(message, cause); }
	public ASAPArgumentException(Throwable cause) { super(cause); }
}
