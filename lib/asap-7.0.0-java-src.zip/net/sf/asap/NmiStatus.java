// Generated automatically with "fut". Do not edit.
package net.sf.asap;

enum NmiStatus
{
	RESET,
	ON_V_BLANK,
	WAS_V_BLANK
}
