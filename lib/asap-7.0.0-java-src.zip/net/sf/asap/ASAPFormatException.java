// Generated automatically with "fut". Do not edit.
package net.sf.asap;

/**
 * Exception thrown when the input file is invalid.
 */
public class ASAPFormatException extends Exception
{
	public ASAPFormatException() { }
	public ASAPFormatException(String message) { super(message); }
	public ASAPFormatException(String message, Throwable cause) { super(message, cause); }
	public ASAPFormatException(Throwable cause) { super(cause); }
}
