// Generated automatically with "fut". Do not edit.
package net.sf.asap;

public class ASAPIOException extends Exception
{
	public ASAPIOException() { }
	public ASAPIOException(String message) { super(message); }
	public ASAPIOException(String message, Throwable cause) { super(message, cause); }
	public ASAPIOException(Throwable cause) { super(cause); }
}
