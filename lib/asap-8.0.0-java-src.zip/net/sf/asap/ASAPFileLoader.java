// Generated automatically with "fut". Do not edit.
package net.sf.asap;

public abstract class ASAPFileLoader
{

	public abstract int load(String filename, byte[] buffer, int length);
}
