// Generated automatically with "fut". Do not edit.
package net.sf.asap;

/**
 * Exception thrown when format conversion fails.
 */
public class ASAPConversionException extends Exception
{
	public ASAPConversionException() { }
	public ASAPConversionException(String message) { super(message); }
	public ASAPConversionException(String message, Throwable cause) { super(message, cause); }
	public ASAPConversionException(Throwable cause) { super(cause); }
}
