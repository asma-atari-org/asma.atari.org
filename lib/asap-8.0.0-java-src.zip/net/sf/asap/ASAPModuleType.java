// Generated automatically with "fut". Do not edit.
package net.sf.asap;

enum ASAPModuleType
{
	SAP_B,
	SAP_C,
	SAP_D,
	SAP_S,
	CMC,
	CM3,
	CMR,
	CMS,
	DLT,
	MPT,
	MD1,
	MD2,
	RMT,
	TMC,
	TM2,
	FC,
	D15
}
